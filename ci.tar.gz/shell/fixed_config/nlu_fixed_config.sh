#!/bin/bash
# nlu每次更新不应该变动的配置文件
# 以key=values格式写在数组内

# 固定不需要修改的配置内容以key=values格式写在数组里面
config=(
)
