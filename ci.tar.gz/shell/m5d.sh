#!/bin/bash
# 2020-06-08
# 用于检测配置文件是否新增配置

function Check() {

old_config=${old_config}
new_config=${new_config}


# 检测所有的配置文件如果出现新增则，copy到老版本的目录

for 




} 
